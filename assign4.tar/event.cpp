/*********************************************************************
** Program Filename: event.cpp
** Author: Ben Lester
** Date: 5/21/206
** Description: event functions
** Input: n/a 
** Output: n/a
*********************************************************************/
#include "event.h"

event::event(){

}
